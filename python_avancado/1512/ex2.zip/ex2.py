try:
    with open("txtTeste.txt","r") as arquivo:
        print(arquivo.read())
        raise PermissionError #Apenas para conseguir executar o except
except FileNotFoundError:
    print("Arquivo não encontrado. Tente ajustar o nome do arquivo")
except PermissionError:
    print("Você não tem permissão para acessar/modificar o arquivo.")