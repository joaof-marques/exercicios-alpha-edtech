contador = 0

def incrementar_contador():
    return contador+1