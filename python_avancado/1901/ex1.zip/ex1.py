import asyncio

async def fazer_cafe():
    print("Iniciando a coagem do café")
    await asyncio.sleep(3)
    print("Coagem do café finalizada")
    
    return "Café coado quentinho"

async def main():
    task_cafe = asyncio.create_task(fazer_cafe())
    cafe = await task_cafe
    
    print(cafe)

if __name__ == "__main__":
    asyncio.run(main())