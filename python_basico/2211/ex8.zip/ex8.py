jogosSouls = {
    "Dark Souls 1": {
        "lancamento": 2011,
        "MetaCritic": 85
    },
    "Dark Souls 2": {
        "lancamento": 2014,
        "MetaCritic": 91
    },
    "Dark Souls 3": {
        "lancamento": 2016,
        "MetaCritic": 89
    },
    "Sekiro: Shadows die twice": {
        "lancamento": 2019,
        "MetaCritic": 90,
        "AntigoDicionario": "Antigo Dicionário"
    },
    "Sekiro: Shadows die twice": {
        "lancamento": 2019,
        "MetaCritic": 90,
        "NovoDicionario": "Novo Dicionario"
    }
}

#Para acessarmos chaves específicas basta passá-la como argumento para o dicionário original:
print(jogosSouls["Dark Souls 3"])