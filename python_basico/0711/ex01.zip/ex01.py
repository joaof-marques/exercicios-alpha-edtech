import math

raio = float(input("Insira o valor do raio da circunferência: "))
area = math.pi * (raio ** raio)
print(f"{area:.4f}")