import random

fitaDNA = ''
basesNitrogenadas = ('A', 'C', 'G', 'T')

for i in range(500):
    baseRandomica = random.randint(0, 3)
    fitaDNA += basesNitrogenadas[baseRandomica]
    
print(fitaDNA)