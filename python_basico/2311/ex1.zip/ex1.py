def factorial (num):
    if num == 1:
        return 1
    else: return num*factorial(num-1)
    
print(factorial(5))
print(factorial(7))
print(factorial(9))
print(factorial(11))