import utilPrimo

print(utilPrimo.gerarNumPrimo(10))