from variaveis import nome, sobrenome, idade, cidade

print(f"Olá! Eu sou o {nome} {sobrenome}. Tenho {idade} anos e moro em {cidade}")