nome = "João"
sobrenome = "Marques"
idade = 28
cidade = "Brasília/DF"