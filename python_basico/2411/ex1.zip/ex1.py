import fatorial 

print(fatorial.calcFatorial(3))
print(fatorial.calcFatorial(4))
print(fatorial.calcFatorial(5))
print(fatorial.calcFatorial(6))