livros = "Vazio"

def imprimirCatalogo ():
    print(livros)