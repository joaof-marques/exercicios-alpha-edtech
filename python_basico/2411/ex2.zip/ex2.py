from fatorial import calcFatorial

# Para importar uma função específica nós primeiro informamos de qual arquivo ela vem: from fatorial
#Logo em seguida, informamos qual função precisa ser importada: import calcFatorial