import modulo1, modulo2

vingadores = modulo2.vingadores()
ligaJustica = modulo2.ligaJustica()

for heroi in vingadores:
    heroi.apresentacao()
    
for heroi in ligaJustica:
    heroi.apresentacao()