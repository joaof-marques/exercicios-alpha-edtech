class superHeroi:
    def __init__(self, nome, time):
        self.nome = nome
        self.time = time
        
    def apresentacao(self):
        print(f"Eu sou o(a) {self.nome} e faço parte da(o) {self.time}")
    