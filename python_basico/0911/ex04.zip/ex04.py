valor = int(input("Insira um número para verificarmos se é par ou ímpar: "))

if valor%2==0:
    print(f"O número {valor} é par!")
else:
    print(f"O número {valor} é ímpar!")