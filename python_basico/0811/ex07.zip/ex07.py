print("Preço","Desconto","Produto", sep='\t')
print("2,50","5","Caneta", sep='\t')
print("10,75","10","Caderno", sep='\t')
print("23,25","15","Mochila", sep='\t')