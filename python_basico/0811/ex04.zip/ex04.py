frase = "Um novo lugar para se trabalhar"

novaFrase = frase.replace("trabalhar", "inspirar")

print(frase)
print(novaFrase)