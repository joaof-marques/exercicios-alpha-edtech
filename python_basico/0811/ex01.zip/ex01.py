primeiroNome = input("Insira o primeiro nome: ")
segundoNome = input("Insira o segundo nome: ")

email = primeiroNome.lower() + "." + segundoNome.lower() + "@gmail.com"

print(f"O email montado é {email}")