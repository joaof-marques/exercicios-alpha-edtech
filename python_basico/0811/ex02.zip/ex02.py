vetor = [0, 1, 2, 3, 4, 5]
print(vetor[1:4])