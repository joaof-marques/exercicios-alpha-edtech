var1 = 10.5
var2 = 15

print(f"Variável 1: {var1}, variável 2: {var2}")
print(f"Variável 1: {var1:.2f}, variável 2: {var2}")
print("Variável 1: %.2f, variável 2: %d" % (var1, var2))