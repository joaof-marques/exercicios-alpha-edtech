produtos_vendidos = [
    ['Caneca', 'Caneta', 'Caderno', 'Caneta', 'Borracha', 'Mouse', 'Teclado', 'Controle Video-Game', 'Caderno', 'Caneta', 'Caneca'],
    [10, 2, 18, 4, 3, 200, 180, 350, 20, 5, 12],
    ['20231120', '20231119','20231117','20231120','20231120','202311219','2023112016','202311214','20231116','202311218','20231119']
]

datas_unicas = set(produtos_vendidos[2])
print(datas_unicas)