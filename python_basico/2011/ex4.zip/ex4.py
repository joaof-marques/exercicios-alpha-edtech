Ainda podemos decidir se queremos que o set seja imutável através da utilização de frozenset. Podemos querer usar isso para situações onde podem ocorrer inserções não desejadas, então o frozenset nos garante a estabilidade dos dados sendo analizados.

